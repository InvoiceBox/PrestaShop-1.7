<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{invoicebox}prestashop>invoicebox_6b834724d74389873e9fdd33f0567abd'] = 'Оплатить через Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_fa214007826415a21a8456e3e09f999d'] = 'Вы уверены что хотите удалить настройки?';
$_MODULE['<{invoicebox}prestashop>invoicebox_c6e985ee3166f07c6f5fdc28d1488e5d'] = 'Введите ID магазина в системе Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_1db82db86f2caa06617aeda9e3690c7c'] = 'Введите Региональный код магазина в системе Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_7c9d0428b7071d44fc133ac6d7eb513b'] = 'Введите Ключ безопасности магазина в системе Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_e0aa021e21dddbd6d8cecec71e9cf564'] = 'OK';
$_MODULE['<{invoicebox}prestashop>invoicebox_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки сохранены';
$_MODULE['<{invoicebox}prestashop>invoicebox_e3664400cb14b0c2f9cffc62dc71544e'] = 'Этот модуль позволяет производить оплату через Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_5dd532f0a63d89c5af0243b74732f63c'] = 'Детали';
$_MODULE['<{invoicebox}prestashop>invoicebox_6cbabda15cbb5a8dd550364ee1cb9693'] = 'Уточните данные';
$_MODULE['<{invoicebox}prestashop>invoicebox_cd8c4daadded9e5c5ddb6243c1214ca6'] = 'ID магазина в системе Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_c19863a5d184b6606ec6fc7e486a006a'] = 'Региональный код магазина в системе Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_952bf87c967660b7bbd4e1eb08cefc92'] = 'Ключ безопасности магазина в системе Invoicebox';
$_MODULE['<{invoicebox}prestashop>invoicebox_4245499695408b974322be6f01b0d17a'] = 'Тестовый режим';
$_MODULE['<{invoicebox}prestashop>invoicebox_b17f3f4dcf653a5776792498a9b44d6a'] = 'Обновить настройки';
$_MODULE['<{invoicebox}prestashop>invoicebox_bf95e18d25f1c0580cf55b5371cfedc3'] = 'Оплатить через Invoicebox';
